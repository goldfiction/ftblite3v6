_____________________________________
NORSECRAFT 3.0
A Viking Texture Pack for Minecraft

Made by Olof Moleman AKA LordTrilobite
Extended beyond 1.6 by kyctarniq

And thanks to all the supporters who come with an endless stream of inspiration and ideas.

_____________________________________

COMPATIBLE WITH MINECRAFT 1.8
_____________________________________

DO NOT REDISTRIBUTE THIS TEXTURE PACK!
_____________________________________

How to install:
1 - Place the .zip file into the resourcepack folder in .minecraft.
2 - Start Minecraft and select NorseCraft in the Resource Pack options.

Includes:

16x16
- Manly gui and hud
- Armour
- Items
- Terrain
- viking decoration
- sun and moon
- title
- Maps and pumpkin overlay

32x32
- wolves
- Zombie as Draugr
- Creeper as Dragon/Lindworm
- Slime as cave troll
- Zombie Pigmen as Surtr's Warriors
- Ghast as Fire Demon
- Endermen as Dark Elves
- Giant Squid
- Scary spider
- Fleshy Skeleton Archer
- Prettier Sheep, Chicken, Pig, Cow and bat

Mod Support
- CTM
- More Health
- Partial support for Balkon's Weapon Mod

Language Pack
This texture pack also includes a language pack that changes the Pirate Speak to Viking speak. It's mostly just English but changes a few things here and there for better immersion. It also changes some of the item names to better fit the style of this texture pack, so I highly recommend using that.

_____________________________________
Changelog:

1.8 v1
- added updates for MC1.7 and MC1.8
- better stats icons
- better diamond block
- updated Minecraft title
- updated Mojang title
- fixed ender crystal

2.1.1
- Hotfix for cobblestone and stone brick

2.1
- made compatible with the new resource pack system of 1.6.2
- added a number of blocks and items like the ender chest, sign, nether star, beacon and more.
- added horse interface
- added witch
- added wither
- tweaked chests
- tweaked zombie villager
- tweaked villager priest
- fixed underside of the enderman head
- fixed support for Balkon's Weapon Mod

2.0
- made compatible with minecraft 1.4.6
- redesigned the interface
- added more terrain like ice and clay
- added more items like redstone dust, gunpowder, clay, and fish.
- added iron golem as a Jotunn/Giant
- added snowman
- added ocelot and cats as lynxes
- added blaze
- added bats

1.9
- made compatible with minecraft 1.2
- added mushrooms, rails, saplings, enchanting table and dragon egg, new coloured planks,
  new stone and sandstone blocks, soulsand and netherwarts.
- changed the bed

1.8
- made compatible with minecraft 1.0

1.7
- made compatible with 1.9 beta
- added cave spider
- added slime as a little bouncy troll
- added zombie pigmen as Surtr's warrior
- added villagers
- added scary ghasts
- added endermen dark elves
- added the Ender Dragon
- added moreHealth support
- added partial support for Balkon's Weapon mod
- enhanced the skeleton, he's now more fleshy and has remains of clothes
- changed music disks to magical runes

1.6
- added trees, foliage and reeds to the terrain
- added glowstone
- added all tools and some other items
- added pig and saddle
- added the last painting
- added minecart
- added CTM support

1.5
- added grass, dirt, snow, gravel and sandstone
- added roses
- added mob spawner
- added boat
- fixed cake and fishingrod bugs

1.4
- made compatible with 1.7 beta
- added redstone as runes
- added ferns and brown mushrooms
- added pistons and shears
- added chicken
- added woodwork ornaments to the trap interface

1.3
- made compatible with 1.6 beta
- added Mojang logo in viking style
- added custom stone, cobblestone, ores and stone slabs
- added scary spider
- added sheep and cow
- added more viking decorations
- added some more items
- fixed some stray pixels

1.2
- made compatible with 1.5 beta
- added wolves and squids
- added round sun and moon
- added pumpkin as skulls and changed pumpkin 1st person view
- added 7 new paintings
- added Norsecraft title logo
- added texture pack icon
- added achievement interface
- changed creeper to a dragon
- changed some items
- changed bed to have a sheepskin

1.1
- added armour
- added items
- added terrain
- added art
- fixed missing trap interface
- added mobs