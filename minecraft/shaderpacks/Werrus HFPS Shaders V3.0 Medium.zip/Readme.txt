THANK YOU FOR DOWNLOADING MY SHADERPACK :)

BEFORE DO ANYTHING, READ THIS AGREEMENT FIRST :

YOU ARE ALLOWED TO :

	
		
- Make videos or pictures with my shaderpack
		
- Modify it only for yourself
		
- Earn money with it from your YouTube Videos
		
- Share my shaderpack link


		
YOU ARE NOT ALLOWED TO :

	
		
- Rename it and claim my shaderpack as your own
		
- Publish your modifications